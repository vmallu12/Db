# Storm Hosting v2 — upgraded storefront

A lightweight Node/Express Storm Hosting storefront with JSON persistence. It is designed for small VPS/Cloudflare Tunnel deployments and does not use native SQLite modules.

## Included
- Modern responsive purple/blue Storm UI
- Minecraft, Discord Bot, VPS, Web, Storage and Dedicated categories
- Admin add/edit/delete-ready plan/category data model
- RAM/CPU/disk/price/billing per plan
- Add to Cart + multi-service checkout
- Discount codes
- Storm User ID tied to a Discord identity field
- Customer/premium tier after a paid order
- Profile editing and password hashing
- Orders, transactions, servers and support tickets
- Admin dashboard for plans, categories, orders, users, discounts and branding
- Pterodactyl Application API provisioning layer (opt-in)
- ZapPay configuration hooks without pretending payments are successful
- Cloudflare Tunnel-friendly binding on `0.0.0.0:7372`

## Run
```bash
cp .env.example .env
nano .env
npm install
npm start
```

Open locally:
`http://localhost:7372`

## PM2
```bash
npm install -g pm2
pm2 start server.js --name storm-hosting
pm2 save
pm2 startup
```

## Admin
Default example credentials are `Admin123` / `admin123`. **Change them in `.env` before exposing the service publicly.**

## Production integrations
The browser must never hold Pterodactyl Application API keys, Discord client secrets, or payment secrets. Put them in `.env`/server-side secret storage.

The included Pterodactyl provisioning code is opt-in (`PTERODACTYL_AUTO_PROVISION=true`) and requires valid plan Nest/Egg IDs. ZapPay live checkout/verification is not guessed because the exact merchant API/webhook contract must be taken from the ZapPay account/documentation.
