const express = require('express');
const session = require('express-session');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { v4: uuid } = require('uuid');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = Number(process.env.PORT || 7372);
const HOST = process.env.HOST || '0.0.0.0';
const DB = path.join(__dirname, 'data', 'db.json');

function ensureDb() {
  fs.mkdirSync(path.dirname(DB), { recursive: true });
  if (!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify({ settings: {}, categories: [], plans: [], users: [], orders: [], discounts: [], transactions: [], tickets: [], servers: [] }, null, 2));
}
ensureDb();

function load() {
  const d = JSON.parse(fs.readFileSync(DB, 'utf8'));
  d.settings ||= {};
  d.categories ||= [];
  d.plans ||= [];
  d.users ||= [];
  d.orders ||= [];
  d.discounts ||= [];
  d.transactions ||= [];
  d.tickets ||= [];
  d.servers ||= [];
  return d;
}
function save(d) { fs.writeFileSync(DB, JSON.stringify(d, null, 2)); }
function secret() { return crypto.randomBytes(24).toString('base64url'); }
function now() { return new Date().toISOString(); }
function safeUser(u) { if (!u) return null; const { passwordHash, ...x } = u; return x; }
function currentUser(req) { const d = load(); return d.users.find(x => x.id === req.session.userId); }
function requireUser(req, res, next) { const u = currentUser(req); if (!u) return res.status(401).json({ error: 'Login required' }); req.user = u; next(); }
function requireAdmin(req, res, next) { if (!req.session.admin) return res.status(401).json({ error: 'Admin login required' }); next(); }
function money(n) { return Math.max(0, Number(n) || 0); }
function publicConfig() {
  const d = load();
  return { settings: d.settings, categories: d.categories.filter(c => c.enabled), plans: d.plans.filter(p => p.enabled) };
}

app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || secret(),
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 7 * 86400000 }
}));
app.use(express.static(path.join(__dirname, 'public')));

// Public config
app.get('/api/config', (req, res) => res.json(publicConfig()));
app.get('/api/me', (req, res) => res.json({ user: safeUser(currentUser(req)), admin: !!req.session.admin }));

// Demo login. Replace with Discord OAuth2 when credentials are configured.
app.post('/api/demo-login', (req, res) => {
  const d = load();
  const discordId = String(req.body.discordId || 'demo-' + uuid());
  let u = d.users.find(x => x.discordId === discordId);
  if (!u) {
    const base = String(req.body.username || 'StormUser').replace(/[^a-zA-Z0-9_.-]/g, '').slice(0, 24) || 'StormUser';
    u = {
      id: 'USR-' + uuid().slice(0, 8).toUpperCase(), discordId, username: base,
      email: base.toLowerCase() + '@storm.fun', role: 'customer', tier: 'normal',
      createdAt: now(), services: [], wallet: 0, passwordHash: null
    };
    d.users.push(u); save(d);
  }
  req.session.userId = u.id;
  req.session.admin = false;
  res.json({ user: safeUser(u), demo: true });
});
app.post('/api/logout', (req, res) => req.session.destroy(() => res.json({ ok: true })));

// Profile
app.put('/api/profile', requireUser, async (req, res) => {
  const d = load(); const u = d.users.find(x => x.id === req.user.id);
  const username = String(req.body.username ?? u.username).trim();
  const email = String(req.body.email ?? u.email).trim();
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) return res.status(400).json({ error: 'Username must be 3-32 characters.' });
  if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ error: 'Enter a valid email.' });
  if (d.users.some(x => x.id !== u.id && x.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: 'Username already in use.' });
  u.username = username; u.email = email;
  if (req.body.password) {
    if (String(req.body.password).length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    u.passwordHash = await bcrypt.hash(String(req.body.password), 10);
  }
  save(d); res.json({ user: safeUser(u) });
});

// Cart
app.get('/api/cart', (req, res) => {
  const d = load();
  const ids = req.session.cart || [];
  const items = ids.map(id => d.plans.find(p => p.id === id && p.enabled)).filter(Boolean);
  res.json({ items, user: safeUser(currentUser(req)) });
});
app.post('/api/cart', (req, res) => {
  const d = load(); const p = d.plans.find(x => x.id === req.body.planId && x.enabled);
  if (!p) return res.status(404).json({ error: 'Plan not found' });
  req.session.cart = [...new Set([...(req.session.cart || []), p.id])];
  res.json({ ok: true });
});
app.delete('/api/cart/:id', (req, res) => { req.session.cart = (req.session.cart || []).filter(id => id !== req.params.id); res.json({ ok: true }); });
app.delete('/api/cart', (req, res) => { req.session.cart = []; res.json({ ok: true }); });

function discountFor(d, code, subtotal) {
  if (!code) return { amount: 0, code: null };
  const x = d.discounts.find(v => v.enabled && v.code.toUpperCase() === String(code).toUpperCase() && (!v.expiresAt || new Date(v.expiresAt) > new Date()) && (!v.maxUses || v.used < v.maxUses));
  if (!x) return { amount: 0, code: null, error: 'Invalid or expired discount code.' };
  const amount = x.type === 'percent' ? Math.min(subtotal, Math.round(subtotal * x.value / 100)) : Math.min(subtotal, x.value);
  return { amount, code: x.code, discountId: x.id };
}
app.post('/api/checkout', requireUser, (req, res) => {
  const d = load(); const ids = req.session.cart || [];
  const plans = ids.map(id => d.plans.find(p => p.id === id && p.enabled)).filter(Boolean);
  if (!plans.length) return res.status(400).json({ error: 'Cart is empty' });
  const subtotal = plans.reduce((a, p) => a + money(p.price), 0);
  const disc = discountFor(d, req.body.discount, subtotal);
  if (disc.error) return res.status(400).json({ error: disc.error });
  const total = subtotal - disc.amount;
  const order = {
    id: 'ORD-' + uuid().slice(0, 8).toUpperCase(), userId: req.user.id,
    items: plans.map(p => p.id), subtotal, discount: disc.amount, discountCode: disc.code,
    total, status: 'pending', paymentProvider: 'ZapPay', paymentCode: null, createdAt: now()
  };
  d.orders.push(order);
  d.transactions.push({ id: 'TXN-' + uuid().slice(0, 8).toUpperCase(), orderId: order.id, userId: req.user.id, amount: total, type: 'payment', status: 'pending', createdAt: now() });
  if (disc.discountId) { const x = d.discounts.find(v => v.id === disc.discountId); x.used = (x.used || 0) + 1; }
  save(d); req.session.cart = [];
  res.json({ order, payment: { provider: 'ZapPay', status: 'pending', checkoutUrl: process.env.ZAPPAY_CHECKOUT_URL || null, message: 'Connect the official ZapPay merchant/API details in .env to enable live checkout.' } });
});
app.get('/api/orders', requireUser, (req, res) => {
  const d = load();
  res.json(d.orders.filter(o => o.userId === req.user.id).map(o => ({ ...o, plans: o.items.map(id => d.plans.find(p => p.id === id)).filter(Boolean) })));
});
app.get('/api/transactions', requireUser, (req, res) => res.json(load().transactions.filter(x => x.userId === req.user.id)));
app.get('/api/servers', requireUser, (req, res) => {
  const d = load(); res.json(d.servers.filter(x => x.userId === req.user.id));
});

// Support
app.get('/api/tickets', requireUser, (req, res) => res.json(load().tickets.filter(x => x.userId === req.user.id)));
app.post('/api/tickets', requireUser, (req, res) => {
  const d = load(); const t = { id: 'TKT-' + uuid().slice(0, 8).toUpperCase(), userId: req.user.id, subject: String(req.body.subject || 'Support request').slice(0, 120), message: String(req.body.message || '').slice(0, 4000), status: 'open', createdAt: now() };
  if (!t.message) return res.status(400).json({ error: 'Message is required.' });
  d.tickets.push(t); save(d); res.json(t);
});

// Admin authentication
app.post('/api/admin/login', async (req, res) => {
  const goodUser = String(req.body.username || '') === String(process.env.ADMIN_USERNAME || 'Admin123');
  const configuredHash = process.env.ADMIN_PASSWORD_HASH;
  let goodPass = false;
  if (configuredHash) goodPass = await bcrypt.compare(String(req.body.password || ''), configuredHash);
  else goodPass = String(req.body.password || '') === String(process.env.ADMIN_PASSWORD || 'admin123');
  if (!goodUser || !goodPass) return res.status(401).json({ error: 'Invalid credentials' });
  req.session.admin = true; res.json({ ok: true });
});
app.post('/api/admin/logout', (req, res) => { req.session.admin = false; res.json({ ok: true }); });
app.get('/api/admin/data', requireAdmin, (req, res) => res.json(load()));
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const d = load(); res.json({ users: d.users.length, orders: d.orders.length, pending: d.orders.filter(o => o.status === 'pending').length, plans: d.plans.length, categories: d.categories.length, tickets: d.tickets.filter(t => t.status === 'open').length, revenue: d.orders.filter(o => o.status === 'paid').reduce((a, o) => a + money(o.total), 0) });
});

// Admin categories
app.post('/api/admin/categories', requireAdmin, (req, res) => {
  const d = load(); const name = String(req.body.name || '').trim(); if (!name) return res.status(400).json({ error: 'Name required' });
  const c = { id: String(req.body.id || uuid()), name: name.slice(0, 50), icon: String(req.body.icon || '📦').slice(0, 8), enabled: req.body.enabled !== false };
  d.categories.push(c); save(d); res.json(c);
});
app.put('/api/admin/categories/:id', requireAdmin, (req, res) => { const d = load(); const c = d.categories.find(x => x.id === req.params.id); if (!c) return res.status(404).json({ error: 'Not found' }); Object.assign(c, { name: req.body.name ?? c.name, icon: req.body.icon ?? c.icon, enabled: req.body.enabled === undefined ? c.enabled : !!req.body.enabled }); save(d); res.json(c); });
app.delete('/api/admin/categories/:id', requireAdmin, (req, res) => { const d = load(); if (d.plans.some(p => p.category === req.params.id)) return res.status(400).json({ error: 'Delete or move the plans in this category first.' }); d.categories = d.categories.filter(x => x.id !== req.params.id); save(d); res.json({ ok: true }); });

// Admin plans
app.post('/api/admin/plans', requireAdmin, (req, res) => {
  const d = load(); const p = normalizePlan(req.body); if (!p.name || !p.category) return res.status(400).json({ error: 'Name and category required' }); p.id = String(req.body.id || uuid()); d.plans.push(p); save(d); res.json(p);
});
function normalizePlan(b, old = {}) {
  return { id: old.id, category: String(b.category ?? old.category ?? ''), name: String(b.name ?? old.name ?? ''), price: money(b.price ?? old.price), ram: Number(b.ram ?? old.ram ?? 1024), disk: Number(b.disk ?? old.disk ?? 10), cpu: Number(b.cpu ?? old.cpu ?? 1), description: String(b.description ?? old.description ?? ''), badge: String(b.badge ?? old.badge ?? ''), enabled: b.enabled === undefined ? (old.enabled ?? true) : !!b.enabled, billing: String(b.billing ?? old.billing ?? 'monthly'), ptero: { nestId: Number(b.nestId ?? old.ptero?.nestId ?? 0), eggId: Number(b.eggId ?? old.ptero?.eggId ?? 0), locationId: Number(b.locationId ?? old.ptero?.locationId ?? 0), nodeId: Number(b.nodeId ?? old.ptero?.nodeId ?? 0), image: String(b.image ?? old.ptero?.image ?? '') } };
}
app.put('/api/admin/plans/:id', requireAdmin, (req, res) => { const d = load(); const p = d.plans.find(x => x.id === req.params.id); if (!p) return res.status(404).json({ error: 'Not found' }); Object.assign(p, normalizePlan(req.body, p)); save(d); res.json(p); });
app.delete('/api/admin/plans/:id', requireAdmin, (req, res) => { const d = load(); d.plans = d.plans.filter(x => x.id !== req.params.id); save(d); res.json({ ok: true }); });

// Admin discounts
app.post('/api/admin/discounts', requireAdmin, (req, res) => { const d = load(); const code = String(req.body.code || '').trim().toUpperCase(); if (!/^[A-Z0-9_-]{3,32}$/.test(code)) return res.status(400).json({ error: 'Invalid code' }); const x = { id: uuid(), code, type: req.body.type === 'fixed' ? 'fixed' : 'percent', value: Math.max(0, Number(req.body.value) || 0), enabled: true, maxUses: Math.max(0, Number(req.body.maxUses) || 0), used: 0, expiresAt: req.body.expiresAt || null }; d.discounts.push(x); save(d); res.json(x); });
app.delete('/api/admin/discounts/:id', requireAdmin, (req, res) => { const d = load(); d.discounts = d.discounts.filter(x => x.id !== req.params.id); save(d); res.json({ ok: true }); });

// Admin settings
app.put('/api/admin/settings', requireAdmin, (req, res) => { const d = load(); const allowed = ['brand','primary','secondary','background','discord','supportEmail','heroTitle','heroSubtitle','announcement','logoUrl']; for (const k of allowed) if (req.body[k] !== undefined) d.settings[k] = String(req.body[k]); save(d); res.json(d.settings); });

// Admin users/orders/tickets
app.get('/api/admin/users', requireAdmin, (req, res) => res.json(load().users.map(safeUser)));
app.put('/api/admin/users/:id', requireAdmin, (req, res) => { const d = load(); const u = d.users.find(x => x.id === req.params.id); if (!u) return res.status(404).json({ error: 'Not found' }); if (req.body.tier) u.tier = req.body.tier; if (req.body.role) u.role = req.body.role; if (req.body.wallet !== undefined) u.wallet = money(req.body.wallet); save(d); res.json(safeUser(u)); });
app.get('/api/admin/orders', requireAdmin, (req, res) => { const d = load(); res.json(d.orders.map(o => ({ ...o, user: safeUser(d.users.find(u => u.id === o.userId)), plans: o.items.map(id => d.plans.find(p => p.id === id)).filter(Boolean) }))); });
app.post('/api/admin/orders/:id/status', requireAdmin, (req, res) => { const d = load(); const o = d.orders.find(x => x.id === req.params.id); if (!o) return res.status(404).json({ error: 'Order not found' }); const old = o.status; o.status = String(req.body.status || 'pending'); const tx = d.transactions.find(t => t.orderId === o.id); if (tx) tx.status = o.status === 'paid' ? 'paid' : o.status; if (o.status === 'paid' && old !== 'paid') provisionOrder(d, o); const u = d.users.find(x => x.id === o.userId); if (u && o.status === 'paid') { u.tier = 'premium'; u.services = [...new Set([...(u.services || []), ...o.items])]; } save(d); res.json(o); });
app.get('/api/admin/tickets', requireAdmin, (req, res) => { const d = load(); res.json(d.tickets.map(t => ({ ...t, user: safeUser(d.users.find(u => u.id === t.userId)) }))); });
app.post('/api/admin/tickets/:id/status', requireAdmin, (req, res) => { const d = load(); const t = d.tickets.find(x => x.id === req.params.id); if (!t) return res.status(404).json({ error: 'Not found' }); t.status = String(req.body.status || 'open'); save(d); res.json(t); });

// Pterodactyl provisioning: only runs after admin marks an order paid and only if all required env + plan fields exist.
async function provisionOrder(d, order) {
  if (!process.env.PTERODACTYL_URL || !process.env.PTERODACTYL_APPLICATION_KEY) return;
  const user = d.users.find(u => u.id === order.userId); if (!user) return;
  for (const planId of order.items) {
    const plan = d.plans.find(p => p.id === planId); if (!plan || !plan.ptero?.nestId || !plan.ptero?.eggId) continue;
    // Provisioning is intentionally opt-in. Set PTERODACTYL_AUTO_PROVISION=true after configuring the API.
    if (process.env.PTERODACTYL_AUTO_PROVISION !== 'true') continue;
    try {
      const base = process.env.PTERODACTYL_URL.replace(/\/$/, '');
      const headers = { Authorization: `Bearer ${process.env.PTERODACTYL_APPLICATION_KEY}`, 'Content-Type': 'application/json', Accept: 'Application/vnd.pterodactyl.v1+json' };
      let email = user.email;
      const usersResp = await fetch(`${base}/api/application/users?filter[email]=${encodeURIComponent(email)}`, { headers });
      if (!usersResp.ok) throw new Error('Pterodactyl user lookup failed');
      const list = await usersResp.json();
      let pUser = list.data?.[0]?.attributes;
      if (!pUser) {
        const password = secret().slice(0, 14);
        const create = await fetch(`${base}/api/application/users`, { method: 'POST', headers, body: JSON.stringify({ username: user.username, email, first_name: user.username, last_name: 'Storm', password }) });
        if (!create.ok) throw new Error('Pterodactyl user creation failed');
        pUser = (await create.json()).attributes;
      }
      const serverName = `${process.env.STORM_NAME || 'Storm'} - ${plan.name}`;
      const payload = { name: serverName, user: pUser.id, nest: plan.ptero.nestId, egg: plan.ptero.eggId, docker_image: plan.ptero.image || 'ghcr.io/pterodactyl/yolks:java_21', startup: plan.startup || '', environment: {}, limits: { memory: plan.ram, swap: 0, disk: plan.disk * 1024, io: 500, cpu: plan.cpu * 100 }, feature_limits: { databases: 1, backups: 1, allocations: 1 } };
      if (plan.ptero.locationId) payload.deploy = { locations: [plan.ptero.locationId], dedicated_ip: false, port_range: [] };
      const createServer = await fetch(`${base}/api/application/servers`, { method: 'POST', headers, body: JSON.stringify(payload) });
      if (!createServer.ok) throw new Error('Pterodactyl server creation failed');
      const created = (await createServer.json()).attributes;
      d.servers.push({ id: 'SRV-' + uuid().slice(0, 8).toUpperCase(), userId: user.id, orderId: order.id, planId: plan.id, pterodactylId: created.id, identifier: created.identifier, name: created.name, status: 'provisioned', createdAt: now() });
    } catch (e) {
      d.servers.push({ id: 'SRV-' + uuid().slice(0, 8).toUpperCase(), userId: user.id, orderId: order.id, planId, name: 'Provisioning pending', status: 'provisioning-error', error: e.message, createdAt: now() });
    }
  }
}

// SPA fallback
app.use((req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, HOST, () => console.log(`Storm Hosting listening on http://${HOST}:${PORT}`));
