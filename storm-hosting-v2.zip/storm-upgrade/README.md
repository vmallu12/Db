# Storm Hosting Shop v2

A lightweight Storm Hosting storefront/admin starter with JSON persistence. It avoids native SQLite dependencies, so it can run on small VPS/Cloudflare Tunnel setups without better-sqlite3.

## Features
- Modern purple/blue Storm shop UI
- Categories and custom plans
- RAM/CPU/disk per plan
- Add to cart and multi-item checkout record
- User IDs linked to Discord identity field
- Normal/Premium customer tier on paid order status
- Orders and transaction records
- Admin authentication from environment variables
- Admin plan add/delete
- Admin category/settings support in API
- Discount-code storage API
- Brand/background/support settings
- Pterodactyl, Discord OAuth, ZapPay env placeholders

## Important
This package intentionally does not fake payment success or create Pterodactyl servers from the browser. Production provisioning must verify the payment server-to-server, then call Pterodactyl's Application API. Add Discord OAuth and ZapPay credentials only to `.env`.

## Run
```bash
cp .env.example .env
nano .env
npm install
npm start
```

The default bind is `127.0.0.1:1`, suitable for a reverse proxy/tunnel. Change PORT if your environment cannot bind port 1.
