# Storm Pterodactyl SSO Bridge

Pterodactyl does not provide a generic "login by external URL" endpoint. The storefront therefore redirects to a custom one-time SSO bridge on the Pterodactyl panel.

The bridge MUST:
1. Accept `/storm-sso?token=payload.signature`.
2. Verify HMAC-SHA256 with the same `SSO_SECRET`.
3. Reject expired or reused tokens.
4. Look up the Pterodactyl user by the numeric user ID from the payload.
5. Create a normal Laravel authenticated session for that user.
6. Redirect to `/server/{identifier}`.
7. Never put a Pterodactyl password in the URL.

This is intentionally a bridge specification rather than an unreviewed modification to Pterodactyl core because the exact Blueprint/Pterodactyl version and routing stack vary.

## Recommended implementation

Implement the route as a small Blueprint extension using your installed Blueprint version's route/component mechanism. The handler can use Laravel's Auth facade to authenticate the existing user.

Pseudo-code:

```php
Route::get('/storm-sso', function (Request $request) {
    $token = $request->query('token');
    // verify signature + expiry + single-use nonce
    // $user = User::findOrFail($payload['uid']);
    // Auth::login($user);
    // return redirect('/server/'.$payload['server']);
});
```

Do NOT simply accept `uid` from the browser. Verify the signed token.
