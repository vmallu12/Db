module.exports = {
  minecraft: [
    { id:"mc-starter", name:"STARTER", price:40, ram:2048, disk:20000, cpu:100, description:"Perfect for getting started", egg:"minecraft" },
    { id:"mc-pro", name:"PRO", price:80, ram:4096, disk:40000, cpu:200, description:"Best for small communities", egg:"minecraft", popular:true },
    { id:"mc-advanced", name:"ADVANCED", price:140, ram:6144, disk:60000, cpu:300, description:"For growing communities", egg:"minecraft" },
    { id:"mc-premium", name:"PREMIUM", price:220, ram:8192, disk:80000, cpu:400, description:"For large networks", egg:"minecraft" }
  ],
  discord: [
    { id:"bot-basic", name:"BASIC BOT", price:30, ram:1024, disk:10000, cpu:75, description:"Simple 24/7 bot hosting", egg:"bot" },
    { id:"bot-standard", name:"STANDARD BOT", price:60, ram:2048, disk:20000, cpu:150, description:"For growing Discord bots", egg:"bot", popular:true },
    { id:"bot-premium", name:"PREMIUM BOT", price:100, ram:4096, disk:30000, cpu:250, description:"For busy communities", egg:"bot" },
    { id:"bot-ultimate", name:"ULTIMATE BOT", price:160, ram:6144, disk:50000, cpu:350, description:"Maximum bot resources", egg:"bot" }
  ],
  vps: [
    { id:"vps-starter", name:"VPS STARTER", price:299, ram:4096, disk:80000, cpu:200, description:"General purpose VPS", egg:"vps" },
    { id:"vps-pro", name:"VPS PRO", price:499, ram:8192, disk:160000, cpu:400, description:"More CPU and memory", egg:"vps", popular:true },
    { id:"vps-advanced", name:"VPS ADVANCED", price:799, ram:16384, disk:240000, cpu:600, description:"For demanding workloads", egg:"vps" },
    { id:"vps-premium", name:"VPS PREMIUM", price:1299, ram:32768, disk:500000, cpu:800, description:"Maximum resources", egg:"vps" }
  ]
};