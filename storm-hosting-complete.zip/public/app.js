let plans={},category="minecraft";
const cats=[["minecraft","🎮","Minecraft Hosting"],["discord","🤖","Discord Bot Hosting"],["vps","🖥️","VPS Hosting"],["web","🌐","Web Hosting"],["storage","💾","Storage"],["dedicated","⚡","Dedicated Servers"]];
async function boot(){
 const me=await fetch("/api/me").then(r=>r.json());
 if(!me.loggedIn){location.href="/";return}
 document.querySelector("#account").textContent=`${me.user.username} • Storm User`;
 plans=await fetch("/api/plans").then(r=>r.json());
 renderCats();renderPlans();
}
function renderCats(){
 document.querySelector("#cats").innerHTML=cats.map(x=>`<button class="${category===x[0]?"active":""}" onclick="selectCat('${x[0]}')">${x[1]} ${x[2]}</button>`).join("");
}
function selectCat(c){category=c;renderCats();renderPlans()}
function renderPlans(){
 const data=plans[category]||plans.minecraft;
 document.querySelector("#sectionTitle").textContent=(cats.find(x=>x[0]===category)?.[2]||"Hosting")+" Plans";
 document.querySelector("#plans").innerHTML=data.map((p,i)=>`<article class="storm-plan ${["green","purple","blue","orange"][i%4]}">
 ${p.popular?'<div class="popular">MOST POPULAR</div>':''}
 <div style="font-size:31px">${category==="minecraft"?"⛏️":category==="discord"?"🤖":"⚡"}</div>
 <h3>${p.name}</h3><div class="sub">${p.description}</div>
 <div class="price">₹${p.price}<small>/month</small></div>
 <ul><li>✓ ${fmtRam(p.ram)}</li><li>✓ ${p.cpu/100} vCore CPU</li><li>✓ ${fmtDisk(p.disk)} NVMe SSD</li><li>✓ Unmetered Bandwidth</li><li>✓ DDoS Protection</li><li>✓ Instant Setup</li></ul>
 <button onclick='buy(${JSON.stringify(p).replaceAll("'","&#39;")})'>Buy Now</button></article>`).join("");
}
function fmtRam(m){return m>=1024?(m/1024)+" GB RAM":m+" MB RAM"}
function fmtDisk(m){return m>=1000?(m/1000)+" GB":m+" MB"}
async function buy(p){
 const modal=document.querySelector("#modal");
 modal.classList.remove("hidden");
 modal.innerHTML=`<div><button class="close" onclick="closeModal()">×</button><div style="font-size:45px">⚡</div><h2>${p.name}</h2><p>${p.description}</p><strong style="font-size:30px">₹${p.price}/month</strong><button class="checkout" id="pay">Continue to ZapPay</button><small class="note">Payment is verified server-side before the Pterodactyl server is created.</small></div>`;
 document.querySelector("#pay").onclick=async()=>{
  document.querySelector("#pay").disabled=true;document.querySelector("#pay").textContent="Creating payment...";
  const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({category,planId:p.id})});
  const d=await r.json();
  if(!r.ok){alert(d.details||"Unable to create order");return}
  location.href=d.paymentUrl;
 };
}
function closeModal(){document.querySelector("#modal").classList.add("hidden")}
boot();
