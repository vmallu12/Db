# Storm Hosting — Production Integration Starter

This project is the server-side storefront for the Storm Hosting UI.

## Flow

Discord OAuth2 -> Storm account -> Buy Now -> ZapPay order -> verified ZapPay status -> Pterodactyl user/server -> Discord DM -> one-click Pterodactyl SSO.

## Important security notes

- Never put ZapPay or Pterodactyl application keys in browser JavaScript.
- Discord OAuth requires a registered redirect URL.
- Pterodactyl SSO is not a native feature. The included `pterodactyl-sso` folder is a small Laravel/Blueprint-style bridge specification. Install it only after reviewing it against your exact Pterodactyl/Blueprint version.
- Do not send a plaintext password to Discord unless you explicitly want that behavior. This starter generates a temporary password and sends it once because that is what the requested workflow asks for; rotate it after first login.
- For a real production deployment, use HTTPS from Cloudflare to the public domain. The app can listen on `localhost:1`; the Cloudflare tunnel terminates HTTPS at the edge.

## Install

```bash
cp .env.example .env
npm install
node server.js
```

Cloudflare Tunnel can point to:

```text
http://127.0.0.1:1
```

Do not expose port 1 directly to the public internet.

## Configure Discord

Create a Discord application and add:

`https://YOUR-SHOP-DOMAIN/auth/discord/callback`

Enable the `identify` and `email` scopes.

## Configure Pterodactyl

Create an Application API key with the minimum permissions required to create users/servers and read nodes/allocations.

Set the actual Nest, Egg, Node/Location and startup/environment values in `.env`.

## Configure ZapPay

Set `ZAPPAY_API_KEY`. The server creates an order using ZapPay's create-order endpoint and verifies it with the order-status endpoint.

## Plans

Edit `plans.js` to change RAM/disk/CPU/prices and map each plan to your Pterodactyl Egg.
