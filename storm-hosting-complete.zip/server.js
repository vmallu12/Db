require("dotenv").config();

const express = require("express");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");
const fetch = (...args) => import("node-fetch").then(({default:f}) => f(...args));

const plans = require("./plans");
const app = express();
const db = new Database(process.env.DB_FILE || "./storm.sqlite");

db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 discord_id TEXT UNIQUE NOT NULL,
 username TEXT NOT NULL,
 email TEXT,
 avatar TEXT,
 ptero_user_id INTEGER,
 ptero_username TEXT,
 ptero_email TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 public_id TEXT UNIQUE NOT NULL,
 user_id INTEGER NOT NULL,
 plan_id TEXT NOT NULL,
 category TEXT NOT NULL,
 amount INTEGER NOT NULL,
 zappay_order_id TEXT,
 status TEXT NOT NULL DEFAULT 'pending',
 ptero_server_id INTEGER,
 ptero_identifier TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 paid_at TEXT
);
`);

app.use(helmet({ contentSecurityPolicy:false }));
app.use(express.json({limit:"100kb"}));
app.use(express.urlencoded({extended:true}));
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || "CHANGE_ME",
  resave:false,
  saveUninitialized:false,
  cookie:{ httpOnly:true, sameSite:"lax", secure: process.env.PUBLIC_URL?.startsWith("https://") || false, maxAge: 7*24*3600*1000 }
}));
app.use(express.static(path.join(__dirname,"public")));

function rand(len=18){ return crypto.randomBytes(len).toString("base64url"); }
function tempPassword(){ return "Storm!" + crypto.randomBytes(6).toString("hex") + "9A"; }
function cleanUsername(name){
  let s=(name||"stormuser").toLowerCase().replace(/[^a-z0-9_]/g,"").slice(0,24);
  if(!s) s="stormuser";
  return s;
}
function stormEmail(username){ return `${username}@storm.fun`; }

function requireLogin(req,res,next){
  if(!req.session.user) return res.status(401).json({error:"LOGIN_REQUIRED"});
  next();
}

function currentUser(req){
  return req.session.user ? db.prepare("SELECT * FROM users WHERE id=?").get(req.session.user.id) : null;
}

function planById(category,id){
  return (plans[category]||[]).find(p=>p.id===id);
}

async function discordToken(code){
  const body=new URLSearchParams({
    client_id:process.env.DISCORD_CLIENT_ID,
    client_secret:process.env.DISCORD_CLIENT_SECRET,
    grant_type:"authorization_code",
    code,
    redirect_uri:process.env.DISCORD_REDIRECT_URI
  });
  const r=await fetch("https://discord.com/api/v10/oauth2/token",{
    method:"POST", headers:{"content-type":"application/x-www-form-urlencoded"}, body
  });
  if(!r.ok) throw new Error("Discord token exchange failed");
  return r.json();
}
async function discordMe(token){
  const r=await fetch("https://discord.com/api/v10/users/@me",{headers:{Authorization:`Bearer ${token}`}});
  if(!r.ok) throw new Error("Discord user lookup failed");
  return r.json();
}

async function ptero(pathname, options={}){
  const r=await fetch(process.env.PTERO_URL.replace(/\/$/,"")+pathname,{
    ...options,
    headers:{
      Authorization:`Bearer ${process.env.PTERO_APPLICATION_API_KEY}`,
      Accept:"Application/vnd.pterodactyl.v1+json",
      "Content-Type":"application/json",
      ...(options.headers||{})
    }
  });
  const text=await r.text();
  let data; try{ data=JSON.parse(text); }catch{ data={raw:text}; }
  if(!r.ok) {
    const e=new Error(`Pterodactyl ${r.status}`);
    e.data=data; throw e;
  }
  return data;
}

async function getOrCreatePteroUser(stormUser){
  if(stormUser.ptero_user_id) {
    try { return await ptero(`/api/application/users/${stormUser.ptero_user_id}`); } catch {}
  }
  const username=cleanUsername(stormUser.username);
  const email=stormEmail(username);
  const password=tempPassword();
  let existing;
  try{
    const q=await ptero(`/api/application/users?filter[email]=${encodeURIComponent(email)}`);
    existing=q.data?.[0];
  }catch{}
  if(existing){
    db.prepare("UPDATE users SET ptero_user_id=?,ptero_username=?,ptero_email=? WHERE id=?")
      .run(existing.attributes.id,existing.attributes.username,existing.attributes.email,stormUser.id);
    return {...existing.attributes,_stormTempPassword:null};
  }
  const first=(stormUser.username||"Storm").replace(/[^a-zA-Z0-9]/g,"").slice(0,32)||"Storm";
  const created=await ptero("/api/application/users",{
    method:"POST",
    body:JSON.stringify({
      email, username, first_name:first, last_name:"User", password, root_admin:false, language:"en"
    })
  });
  const a=created.attributes;
  db.prepare("UPDATE users SET ptero_user_id=?,ptero_username=?,ptero_email=? WHERE id=?")
    .run(a.id,a.username,a.email,stormUser.id);
  return {...a,_stormTempPassword:password};
}

async function freeAllocation(){
  const nodeIds=(process.env.PTERO_LOCATION_IDS||"").split(",").map(Number).filter(Boolean);
  if(!nodeIds.length) throw new Error("Set PTERO_LOCATION_IDS to a node/location id");
  for(const nodeId of nodeIds){
    const page=await ptero(`/api/application/nodes/${nodeId}/allocations?per_page=100`);
    const row=(page.data||[]).find(x=>!x.attributes.assigned);
    if(row) return {nodeId,allocationId:row.attributes.id};
  }
  throw new Error("No free Pterodactyl allocation available");
}

function envFor(plan, category){
  let base={};
  try{ base=JSON.parse(category==="minecraft" ? (process.env.PTERO_MINECRAFT_ENV||"{}") : (process.env.PTERO_BOT_ENV||"{}")); }catch{}
  return {
    ...base,
    SERVER_MEMORY:String(plan.ram),
    SERVER_DISK:String(plan.disk),
    SERVER_CPU:String(plan.cpu)
  };
}

async function createPteroServer(stormUser, plan, category){
  const user=await getOrCreatePteroUser(stormUser);
  const alloc=await freeAllocation();
  const egg=category==="minecraft" ? Number(process.env.PTERO_MINECRAFT_EGG_ID) : Number(process.env.PTERO_BOT_EGG_ID);
  const image=category==="minecraft" ? (process.env.PTERO_DOCKER_IMAGE||"ghcr.io/pterodactyl/yolks:java_21") : (process.env.PTERO_BOT_DOCKER_IMAGE||"ghcr.io/pterodactyl/yolks:python_3.12");
  const startup=category==="minecraft" ? process.env.PTERO_STARTUP : process.env.PTERO_BOT_STARTUP;
  const name=`Storm ${plan.name} • ${stormUser.username}`;
  const body={
    name,
    user:user.id,
    nest:Number(process.env.PTERO_DEFAULT_NEST_ID),
    egg,
    docker_image:image,
    startup,
    environment:envFor(plan,category),
    limits:{memory:plan.ram,swap:0,disk:plan.disk,io:500,cpu:plan.cpu},
    feature_limits:{databases:2,allocations:1,backups:2},
    deployment:{locations:[alloc.nodeId],dedicated_ip:false,port_range:[]},
    allocation:{default:alloc.allocationId}
  };
  const created=await ptero("/api/application/servers",{method:"POST",body:JSON.stringify(body)});
  return {server:created.attributes,user,allocation:alloc};
}

async function zapCreate(amount,title){
  const r=await fetch(`${process.env.ZAPPAY_BASE_URL||"https://panel.zappay.shop"}/api/developer/create-order`,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({zap_api:process.env.ZAPPAY_API_KEY,amount,title})
  });
  const text=await r.text(); let data; try{data=JSON.parse(text)}catch{data={raw:text}};
  if(!r.ok) { const e=new Error("ZapPay create order failed"); e.data=data; throw e; }
  return data;
}

async function zapStatus(orderId){
  const r=await fetch(`${process.env.ZAPPAY_BASE_URL||"https://panel.zappay.shop"}/api/developer/order-status/${encodeURIComponent(orderId)}`,{
    headers:{"Accept":"application/json"}
  });
  const text=await r.text(); let data; try{data=JSON.parse(text)}catch{data={raw:text}};
  if(!r.ok) { const e=new Error("ZapPay status failed"); e.data=data; throw e; }
  return data;
}

async function dmDiscord(userId, content){
  if(process.env.DISCORD_DM_ENABLED==="false") return;
  const r=await fetch(`https://discord.com/api/v10/users/@me/channels`,{
    method:"POST",headers:{Authorization:`Bot ${process.env.DISCORD_BOT_TOKEN}`,"Content-Type":"application/json"},
    body:JSON.stringify({recipient_id:String(userId)})
  });
  if(!r.ok) throw new Error("Unable to open Discord DM");
  const ch=await r.json();
  const rr=await fetch(`https://discord.com/api/v10/channels/${ch.id}/messages`,{
    method:"POST",headers:{Authorization:`Bot ${process.env.DISCORD_BOT_TOKEN}`,"Content-Type":"application/json"},
    body:JSON.stringify({content})
  });
  if(!rr.ok) throw new Error("Unable to send Discord DM");
}

app.get("/auth/discord",(req,res)=>{
  const state=rand(24); req.session.oauthState=state;
  const params=new URLSearchParams({
    client_id:process.env.DISCORD_CLIENT_ID,
    response_type:"code",
    redirect_uri:process.env.DISCORD_REDIRECT_URI,
    scope:"identify email",
    state,
    prompt:"consent"
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params}`);
});

app.get("/auth/discord/callback",async(req,res)=>{
  try{
    if(!req.query.code || req.query.state!==req.session.oauthState) return res.status(400).send("Invalid OAuth state.");
    const tok=await discordToken(req.query.code);
    const d=await discordMe(tok.access_token);
    let u=db.prepare("SELECT * FROM users WHERE discord_id=?").get(d.id);
    if(!u){
      const info=db.prepare("INSERT INTO users(discord_id,username,email,avatar) VALUES(?,?,?,?)")
        .run(d.id,d.username,d.email||null,d.avatar||null);
      u=db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);
    }else{
      db.prepare("UPDATE users SET username=?,email=?,avatar=? WHERE id=?").run(d.username,d.email||u.email,d.avatar||u.avatar,u.id);
      u=db.prepare("SELECT * FROM users WHERE id=?").get(u.id);
    }
    req.session.user={id:u.id,discord_id:u.discord_id};
    res.redirect("/dashboard.html");
  }catch(e){ console.error(e); res.status(500).send("Discord login failed."); }
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/me",(req,res)=>{
  const u=currentUser(req);
  if(!u) return res.json({loggedIn:false});
  res.json({loggedIn:true,user:{id:u.id,discord_id:u.discord_id,username:u.username,email:u.email,avatar:u.avatar,ptero_user_id:u.ptero_user_id}});
});

app.get("/api/plans",(req,res)=>res.json(plans));

app.post("/api/orders",requireLogin,async(req,res)=>{
  try{
    const {category,planId}=req.body;
    const plan=planById(category,planId);
    if(!plan) return res.status(400).json({error:"INVALID_PLAN"});
    const u=currentUser(req);
    const publicId="ST-"+Date.now().toString(36).toUpperCase()+"-"+rand(4).toUpperCase();
    const title=`Storm Hosting - ${category} - ${plan.name}`;
    const z=await zapCreate(plan.price,title);
    const orderId=z.order_id || z.orderId || z.data?.order_id || z.data?.orderId;
    const paymentUrl=z.payment_url || z.paymentUrl || z.data?.payment_url || z.data?.paymentUrl;
    if(!orderId || !paymentUrl) throw new Error("ZapPay response did not contain order_id/payment_url");
    db.prepare("INSERT INTO orders(public_id,user_id,plan_id,category,amount,zappay_order_id) VALUES(?,?,?,?,?,?)")
      .run(publicId,u.id,plan.id,category,plan.price,String(orderId));
    res.json({publicId,paymentUrl,orderId});
  }catch(e){ console.error(e.data||e); res.status(500).json({error:"ORDER_CREATE_FAILED",details:e.message}); }
});

app.get("/api/orders/:publicId",requireLogin,async(req,res)=>{
  const u=currentUser(req);
  const o=db.prepare("SELECT * FROM orders WHERE public_id=? AND user_id=?").get(req.params.publicId,u.id);
  if(!o) return res.status(404).json({error:"NOT_FOUND"});
  try{
    if(o.status==="pending"){
      const s=await zapStatus(o.zappay_order_id);
      const status=String(s.status || s.data?.status || "").toLowerCase();
      if(status==="success"){
        db.prepare("UPDATE orders SET status='paid',paid_at=CURRENT_TIMESTAMP WHERE id=?").run(o.id);
        o.status="paid";
      }else if(status==="failed"){
        db.prepare("UPDATE orders SET status='failed' WHERE id=?").run(o.id);
        o.status="failed";
      }
    }
    if(o.status==="paid" && !o.ptero_server_id){
      const plan=planById(o.category,o.plan_id);
      const result=await createPteroServer(u,plan,o.category);
      db.prepare("UPDATE orders SET ptero_server_id=?,ptero_identifier=?,status='provisioned' WHERE id=?")
        .run(result.server.id,result.server.identifier,o.id);
      o.status="provisioned"; o.ptero_server_id=result.server.id; o.ptero_identifier=result.server.identifier;
      const temp=result.user._stormTempPassword;
      const msg=[
        "⚡ **STORM HOSTING — ORDER COMPLETE**",
        "",
        `Plan: **${plan.name}**`,
        `Amount: **₹${plan.price}**`,
        `Pterodactyl Server: **${result.server.name}**`,
        `Server ID: **${result.server.identifier}**`,
        "",
        `Panel: ${process.env.PTERO_URL}`,
        `Username: **${result.user.username}**`,
        `Email: **${result.user.email}**`,
        temp ? `Temporary password: **${temp}**` : "Your existing Pterodactyl account was used.",
        "",
        "Please change the temporary password after your first login."
      ].join("\n");
      try{ await dmDiscord(u.discord_id,msg); }catch(e){ console.error("Discord DM:",e.message); }
    }
    res.json(o);
  }catch(e){ console.error(e.data||e); res.status(500).json({error:"PROVISION_FAILED",details:e.message}); }
});

app.get("/api/my-orders",requireLogin,(req,res)=>{
  const u=currentUser(req);
  res.json(db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC").all(u.id));
});

app.get("/api/sso/:serverId",requireLogin,(req,res)=>{
  const u=currentUser(req);
  const o=db.prepare("SELECT * FROM orders WHERE user_id=? AND ptero_server_id=? AND status='provisioned'").get(u.id,Number(req.params.serverId));
  if(!o) return res.status(404).send("Server not found.");
  // The SSO bridge is intentionally separated from the storefront.
  const exp=Date.now()+60_000;
  const payload=Buffer.from(JSON.stringify({uid:u.ptero_user_id,server:o.ptero_identifier,exp})).toString("base64url");
  const sig=crypto.createHmac("sha256",process.env.SSO_SECRET||"CHANGE_ME").update(payload).digest("base64url");
  res.redirect(`${process.env.PTERO_URL}${process.env.PTERO_SSO_PATH||"/storm-sso"}?token=${payload}.${sig}`);
});

app.listen(Number(process.env.PORT||1),"127.0.0.1",()=>console.log(`Storm Hosting listening on 127.0.0.1:${process.env.PORT||1}`));
